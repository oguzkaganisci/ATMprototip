print("Bankamatiğe hoş geldiniz 🏦")

dogru_pin = "1234"
girilen_pin = input("Lütfen PIN giriniz: ")

if girilen_pin == dogru_pin:
    print("PIN doğru. Hoş geldiniz ✅\n")

    bakiye = 20000
    iban = "TR50001"

    # Sonsuz gibi çalışan for döngüsü
    for i in range(999999999):
        print("\n--- MENÜ ---")
        print("1 - IBAN kontrol")
        print("2 - Para yatırma")
        print("3 - Para çekme")
        print("4 - Bakiye görüntüleme")
        print("5 - Çıkış")

        secim = int(input("Seçim girin: "))

        if secim == 1:
            print("IBAN:", iban)

        elif secim == 2:
            miktar = int(input("Yatırılacak miktar: "))
            if miktar <= 0:
                print("Geçersiz miktar ❌")
            elif miktar > 20000:
                print("Bu para miktarı yatırılamaz ❌ (Max 20.000 TL)")
            else:
                bakiye += miktar
                print("Yeni bakiye:", bakiye, "TL")

        elif secim == 3:
            cekilecek = int(input("Çekilecek miktar: "))
            if cekilecek <= 0:
                print("Pozitif bir miktar girin ❌")
            elif cekilecek > bakiye:
                print("Yetersiz bakiye ❌")
            else:
                bakiye -= cekilecek
                print("Paranızı alınız. Kalan bakiye:", bakiye, "TL")

        elif secim == 4:
            print("Mevcut bakiye:", bakiye, "TL")

        elif secim == 5:
            print("Çıkış yapılıyor... 👋")
            break  # döngüden çıkış

        else:
            print("Geçersiz seçim ❌")

else:
    print("Yanlış PIN girdiniz ❌")
